// Netlify serverless function — reachable at /.netlify/functions/verify-payment
// netlify.toml redirects /api/verify-payment here so the frontend fetch() call
// doesn't need to change. Set PAYSTACK_SECRET_KEY in Site settings →
// Environment variables. Never commit it.

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
};

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: SECURITY_HEADERS, body: JSON.stringify({ verified: false, error: 'Method not allowed' }) };
  }

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, headers: SECURITY_HEADERS, body: JSON.stringify({ verified: false, error: 'Invalid JSON body' }) };
  }

  const { reference, expectedAmount } = body;
  const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY;

  if (typeof reference !== 'string' || !reference.trim() || reference.length > 100) {
    return { statusCode: 400, headers: SECURITY_HEADERS, body: JSON.stringify({ verified: false, error: 'Invalid reference' }) };
  }
  if (typeof expectedAmount !== 'number' || !Number.isFinite(expectedAmount) || expectedAmount <= 0) {
    return { statusCode: 400, headers: SECURITY_HEADERS, body: JSON.stringify({ verified: false, error: 'Invalid expectedAmount' }) };
  }
  if (!PAYSTACK_SECRET_KEY) {
    console.error('PAYSTACK_SECRET_KEY is not set in Netlify environment variables');
    return { statusCode: 500, headers: SECURITY_HEADERS, body: JSON.stringify({ verified: false, error: 'Server not configured' }) };
  }

  try {
    const psRes = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${PAYSTACK_SECRET_KEY}` },
    });
    const data = await psRes.json();

    if (!psRes.ok || !data.status || data.data?.status !== 'success') {
      return { statusCode: 200, headers: SECURITY_HEADERS, body: JSON.stringify({ verified: false }) };
    }

    const paidAmount = data.data.amount / 100;
    const amountMatches = Math.abs(paidAmount - expectedAmount) < 0.01;
    const currencyMatches = data.data.currency === 'KES';

    if (!amountMatches || !currencyMatches) {
      console.warn(`Verify mismatch for ${reference}: paid ${paidAmount} ${data.data.currency}, expected ${expectedAmount} KES`);
      return { statusCode: 200, headers: SECURITY_HEADERS, body: JSON.stringify({ verified: false }) };
    }

    // Deliberately minimal response — no customer PII echoed back to whoever
    // holds a reference, since references aren't secret.
    return { statusCode: 200, headers: SECURITY_HEADERS, body: JSON.stringify({ verified: true }) };
  } catch (err) {
    console.error('Paystack verify error:', err.message);
    return { statusCode: 502, headers: SECURITY_HEADERS, body: JSON.stringify({ verified: false, error: 'Verification request failed' }) };
  }
};
