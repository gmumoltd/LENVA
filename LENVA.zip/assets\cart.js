/* LEVNA — cart (localStorage-backed) */

const CART_KEY = 'levna_cart';

function escapeHTML(str){
  return String(str ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function getCart(){
  try{
    return JSON.parse(localStorage.getItem(CART_KEY)) || [];
  }catch(e){
    return [];
  }
}

function saveCart(cart){
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  renderCart();
}

function fmt(amount){
  return 'KSh ' + Math.round(amount).toLocaleString('en-KE');
}

function addToCart(id, name, variant, price){
  const cart = getCart();
  const existing = cart.find(i => i.id === id);
  if(existing){
    existing.qty += 1;
  }else{
    cart.push({ id, name, variant, price, qty: 1 });
  }
  saveCart(cart);
  showToast(`${name} added to cart`);
}

function removeFromCart(id){
  saveCart(getCart().filter(i => i.id !== id));
}

function changeQty(id, delta){
  const cart = getCart();
  const item = cart.find(i => i.id === id);
  if(!item) return;
  item.qty += delta;
  if(item.qty <= 0){
    saveCart(cart.filter(i => i.id !== id));
  }else{
    saveCart(cart);
  }
}

function openCart(){
  document.getElementById('cartDrawer')?.classList.add('open');
  document.getElementById('cartOverlay')?.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeCart(){
  document.getElementById('cartDrawer')?.classList.remove('open');
  document.getElementById('cartOverlay')?.classList.remove('open');
  document.body.style.overflow = '';
}

let toastTimer;
function showToast(msg){
  const toast = document.getElementById('cartToast');
  if(!toast) return;
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2200);
}

function renderCart(){
  const cart = getCart();
  const count = cart.reduce((a, i) => a + i.qty, 0);
  const subtotal = cart.reduce((a, i) => a + i.price * i.qty, 0);

  document.querySelectorAll('#cartBadge').forEach(el => {
    el.textContent = count;
    el.classList.toggle('zero', count === 0);
  });
  document.querySelectorAll('#cartSubtotal').forEach(el => {
    el.textContent = fmt(subtotal);
  });

  const itemsEl = document.getElementById('cartItems');
  if(itemsEl){
    if(cart.length === 0){
      itemsEl.innerHTML = '<p class="cart-empty">Your cart is empty.</p>';
    }else{
      itemsEl.innerHTML = cart.map(i => `
        <div class="cart-item">
          <div class="cart-item-info">
            <p class="cart-item-name">${escapeHTML(i.name)}</p>
            <p class="cart-item-variant">${escapeHTML(i.variant)}</p>
            <div class="cart-item-row">
              <div class="cart-item-qty">
                <button onclick="changeQty('${escapeHTML(i.id)}',-1)" aria-label="Decrease quantity">−</button>
                <span>${i.qty}</span>
                <button onclick="changeQty('${escapeHTML(i.id)}',1)" aria-label="Increase quantity">+</button>
              </div>
              <span class="cart-item-price">${fmt(i.price * i.qty)}</span>
            </div>
            <button class="cart-item-remove" onclick="removeFromCart('${escapeHTML(i.id)}')">Remove</button>
          </div>
        </div>`).join('');
    }
  }
}

function toggleMenu(){
  const drawer = document.getElementById('navDrawer');
  const overlay = document.getElementById('navDrawerOverlay');
  const toggle = document.querySelector('.nav-toggle');
  const open = drawer.classList.toggle('open');
  overlay.classList.toggle('open', open);
  toggle.classList.toggle('open', open);
  toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  document.body.style.overflow = open ? 'hidden' : '';
}

function closeMenu(){
  document.getElementById('navDrawer')?.classList.remove('open');
  document.getElementById('navDrawerOverlay')?.classList.remove('open');
  const toggle = document.querySelector('.nav-toggle');
  toggle?.classList.remove('open');
  toggle?.setAttribute('aria-expanded', 'false');
  document.body.style.overflow = '';
}

function openSearch(){
  document.getElementById('searchOverlay')?.classList.add('open');
  document.body.style.overflow = 'hidden';
  setTimeout(() => document.getElementById('searchInput')?.focus(), 100);
}

function closeSearch(){
  document.getElementById('searchOverlay')?.classList.remove('open');
  document.body.style.overflow = '';
}

function submitSearch(event){
  event.preventDefault();
  const q = document.getElementById('searchInput').value.trim();
  window.location.href = 'collection.html' + (q ? '?q=' + encodeURIComponent(q) : '');
}

function filterCollectionByQuery(){
  const params = new URLSearchParams(window.location.search);
  const q = params.get('q');
  if(!q) return;
  const query = q.toLowerCase();
  document.querySelectorAll('.product-card').forEach(card => {
    const name = (card.querySelector('.product-name')?.textContent || '').toLowerCase();
    const variant = (card.querySelector('.product-variant')?.textContent || '').toLowerCase();
    card.style.display = (name.includes(query) || variant.includes(query)) ? '' : 'none';
  });
  const heading = document.querySelector('.collection-header .section-title');
  if(heading) heading.innerHTML = `Results for<br><em>"${escapeHTML(q)}"</em>`;
}

function initNavScroll(){
  const nav = document.querySelector('nav.nav-overlay');
  if(!nav) return;
  const onScroll = () => nav.classList.toggle('scrolled', window.scrollY > 60);
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });
}

document.addEventListener('DOMContentLoaded', () => {
  renderCart();
  initNavScroll();
  filterCollectionByQuery();
  document.querySelectorAll('.nav-drawer-links a').forEach(a => a.addEventListener('click', closeMenu));
  document.addEventListener('keydown', e => {
    if(e.key === 'Escape'){ closeMenu(); closeSearch(); closeCart(); }
  });
});
