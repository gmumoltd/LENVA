// Vercel serverless function — auto-routed from /api/verify-payment
// Set PAYSTACK_SECRET_KEY in your Vercel project's Environment Variables
// (Project Settings → Environment Variables). Never commit it.

module.exports = async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  if (req.method !== 'POST') {
    res.status(405).json({ verified: false, error: 'Method not allowed' });
    return;
  }

  const { reference, expectedAmount } = req.body || {};
  const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY;

  if (typeof reference !== 'string' || !reference.trim() || reference.length > 100) {
    res.status(400).json({ verified: false, error: 'Invalid reference' });
    return;
  }
  if (typeof expectedAmount !== 'number' || !Number.isFinite(expectedAmount) || expectedAmount <= 0) {
    res.status(400).json({ verified: false, error: 'Invalid expectedAmount' });
    return;
  }
  if (!PAYSTACK_SECRET_KEY) {
    console.error('PAYSTACK_SECRET_KEY is not set in Vercel environment variables');
    res.status(500).json({ verified: false, error: 'Server not configured' });
    return;
  }

  try {
    const psRes = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${PAYSTACK_SECRET_KEY}` },
    });
    const data = await psRes.json();

    if (!psRes.ok || !data.status || data.data?.status !== 'success') {
      res.status(200).json({ verified: false });
      return;
    }

    const paidAmount = data.data.amount / 100;
    const amountMatches = Math.abs(paidAmount - expectedAmount) < 0.01;
    const currencyMatches = data.data.currency === 'KES';

    if (!amountMatches || !currencyMatches) {
      console.warn(`Verify mismatch for ${reference}: paid ${paidAmount} ${data.data.currency}, expected ${expectedAmount} KES`);
      res.status(200).json({ verified: false });
      return;
    }

    // Deliberately minimal response — no customer PII echoed back to whoever
    // holds a reference, since references aren't secret.
    res.status(200).json({ verified: true });
  } catch (err) {
    console.error('Paystack verify error:', err.message);
    res.status(502).json({ verified: false, error: 'Verification request failed' });
  }
};
