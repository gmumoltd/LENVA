require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '10kb' }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});
app.use(express.static(__dirname));

const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY;

// Very small in-memory rate limiter — enough to blunt casual reference
// scanning on a single-process deployment. Resets on restart; if you deploy
// behind multiple instances, replace with a shared store (e.g. Redis).
const hits = new Map();
function rateLimited(ip, max = 20, windowMs = 60_000) {
  const now = Date.now();
  const entry = hits.get(ip) || { count: 0, resetAt: now + windowMs };
  if (now > entry.resetAt) {
    entry.count = 0;
    entry.resetAt = now + windowMs;
  }
  entry.count += 1;
  hits.set(ip, entry);
  return entry.count > max;
}

app.post('/api/verify-payment', async (req, res) => {
  if (rateLimited(req.ip)) {
    return res.status(429).json({ verified: false, error: 'Too many requests, try again shortly' });
  }

  const { reference, expectedAmount } = req.body || {};

  if (typeof reference !== 'string' || !reference.trim() || reference.length > 100) {
    return res.status(400).json({ verified: false, error: 'Invalid reference' });
  }
  if (typeof expectedAmount !== 'number' || !Number.isFinite(expectedAmount) || expectedAmount <= 0) {
    return res.status(400).json({ verified: false, error: 'Invalid expectedAmount' });
  }
  if (!PAYSTACK_SECRET_KEY) {
    console.error('PAYSTACK_SECRET_KEY is not set — create a .env file (see .env.example)');
    return res.status(500).json({ verified: false, error: 'Server not configured' });
  }

  try {
    const psRes = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${PAYSTACK_SECRET_KEY}` },
    });
    const data = await psRes.json();

    if (!psRes.ok || !data.status || data.data?.status !== 'success') {
      return res.json({ verified: false });
    }

    const paidAmount = data.data.amount / 100;
    const amountMatches = Math.abs(paidAmount - expectedAmount) < 0.01;
    const currencyMatches = data.data.currency === 'KES';

    if (!amountMatches || !currencyMatches) {
      console.warn(`Verify mismatch for ${reference}: paid ${paidAmount} ${data.data.currency}, expected ${expectedAmount} KES`);
      return res.json({ verified: false });
    }

    // Deliberately minimal response — the client already knows its own order
    // details; we don't echo back customer PII (email etc.) to whoever holds
    // a reference, since references aren't secret.
    return res.json({ verified: true });
  } catch (err) {
    console.error('Paystack verify error:', err.message);
    return res.status(502).json({ verified: false, error: 'Verification request failed' });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`LEVNA server running at http://localhost:${PORT}`));
